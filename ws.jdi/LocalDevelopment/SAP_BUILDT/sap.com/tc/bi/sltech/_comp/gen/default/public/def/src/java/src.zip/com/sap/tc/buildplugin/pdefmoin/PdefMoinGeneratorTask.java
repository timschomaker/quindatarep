package com.sap.tc.buildplugin.pdefmoin;

import com.sap.tc.buildplugin.pdef.PdefGeneratorTask;
import com.sap.tc.buildplugin.scdef.EdenBuildPlugin;

public class PdefMoinGeneratorTask extends PdefGeneratorTask {

//    @Override
//	protected Connection getMoinConnection () {
//    	Connection connection = null;
//	    log( "Trying to get the MOIN connection..." );
//	    // get the moin connection
//	    MoinTaskData taskData = getTaskData();
//	    if (taskData != null) {
//	      connection = taskData.getConnection( );
//	    }
//	    if (connection == null) {
//	    	log( "...no connection available: " + connection );
//	    } else {
//	    	log( "...got it: " + connection );
//	    }
//	    return connection;
//    }
    
    @Override
	protected EdenBuildPlugin getPluginInstance() {
    	return new PdefMoinValidator();
    }
}
