package com.sap.tc.buildplugin.scdef;

import java.io.File;

public final class Cdir {

	private File dir;
	
	public File getCdir() {
		return dir;
	}
	
	public void setCdir (File name) {
		dir = name;
	}
	
	@Override
	public String toString() {
		return String.valueOf(dir);
	}
}
