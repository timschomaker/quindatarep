package com.sap.tc.buildplugin.slentity;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.pp.AbstractEntityHandler;
import com.sap.tc.buildplugin.pp.EntityDataProvider;
import com.sap.tc.buildplugin.pp.IEntityFileSet;
import com.sap.tc.buildplugin.pp.PackerDestination;
import com.sap.tc.buildplugin.pp.api.IEntity;
import com.sap.tc.buildplugin.pp.util.FileSet;
import com.sap.tc.buildplugin.pp.util.PathIdentifier;
import com.sap.tc.buildplugin.util.ConfigurationException;

public class SlDataEntity extends AbstractEntityHandler {
	
	public static final String GENERATED_TEMP_FOLDER = "gensrc";
	
	private PackerDestination destination;

	public SlDataEntity() {

		destination = PackerDestination.JAVALIB;
	}

	@Override
	@SuppressWarnings("unchecked")
	public void configure(Map configuration) throws ConfigurationException {

		String dest = (String) configuration.get("destination"); //$NON-NLS-1$
		if (dest != null) {
			destination = PackerDestination.fromString(dest);
		}
	}

	public void determineFileList(IEntityFileSet entityFileSet, IEntity entity,
			EntityDataProvider provider) {

		List<PathIdentifier> folders = provider.getDCPaths();

		packFolder(folders, provider, entity, entityFileSet);
	}

	@SuppressWarnings("unchecked")
	protected void packFolder(List folders, EntityDataProvider provider,
			IEntity entity, IEntityFileSet fileList) {

		IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager
				.getFromBuildSession(IPluginBuildInfo.class.getName());

		Log.info("DC being built: " + pbi.getCurrentDevelopmentComponent().getName()); //$NON-NLS-1$

		// add sources
		String fullName = entity.getName();
		if (folders != null) {
			boolean found = false;
			Log.info("Searching for entity: " + fullName + "."); //$NON-NLS-1$//$NON-NLS-2$
			for (int i = 0; i < folders.size(); i++) {
				PathIdentifier path = (PathIdentifier) folders.get(i);
				String pathName = path.getPath();
				Log.info("Checking path: " + pathName); //$NON-NLS-1$
				if (fullName.startsWith(pathName)) {
					found = true;

					FileSet fs = provider.createFileSet(PathIdentifier.DC_ROOT);

					prepareFileSet(fs, entity, fullName, "**/*"); //$NON-NLS-1$

					fileList.addFileSet(getPackerDestination(), fs);
					fs.dispose();

					fs = provider.createFileSet(PathIdentifier.DC_ROOT);
					File root = new File(provider.getTempDir(),
							SlDataEntity.GENERATED_TEMP_FOLDER);

					if (root.exists()) {
						fs.setRoot(root);

						prepareFileSet(fs, entity, fullName, "**/*"); //$NON-NLS-1$

						fileList.addFileSet(getPackerDestination(), fs);
						fs.dispose();
					} else {
						Log.warn("Entity '{0}' could not be packed, because the generation root id abscent.", fullName); //$NON-NLS-1$
					}
				}
			}

			if (!found) {
				Log.warn("Model Folder Tree '{0}' is outside of defined package or source folders.", fullName); //$NON-NLS-1$
			}
		}

	}

	protected PackerDestination getPackerDestination() {

		return destination;
	}

	@SuppressWarnings("unchecked")
	protected static void prepareFileSet(FileSet fs, IEntity entity,
			String fullName, String includeString) {

		List includes = entity.getIncludes();
		List excludes = entity.getExcludes();

		if ((includes != null) && (includes.size() > 0)) {
			for (int j = 0; j < includes.size(); j++) {
				String s = (String) includes.get(j);
				fs.addInclude(concatFilterString(fullName, s));
			}
		} else {
			fs.addInclude(concatFilterString(fullName, includeString));
		}
		if ((excludes != null) && (excludes.size() > 0)) {
			for (int j = 0; j < excludes.size(); j++) {
				String s = (String) excludes.get(j);
				fs.addExclude(concatFilterString(fullName, s));
			}
		}
	}

	private static String concatFilterString(String fullName,
			String filterString) {

		StringBuffer b = new StringBuffer(fullName.length()
				+ filterString.length() + 2);

		b.append(fullName);

		if (!fullName.endsWith("/")) { //$NON-NLS-1$
			b.append("/"); //$NON-NLS-1$
		}

		b.append(filterString);

		return b.toString();
	}

}
