package com.sap.tc.buildplugin.pdefmoin;

import com.sap.tc.buildplugin.pdef.PdefBuildFileCreator;

public class PdefMoinBuildFileCreator extends PdefBuildFileCreator {
	
	@Override
	protected String getGeneratorChainName() {
    	return "sap.com~sl.pdef_moin_chain";
    }
}
