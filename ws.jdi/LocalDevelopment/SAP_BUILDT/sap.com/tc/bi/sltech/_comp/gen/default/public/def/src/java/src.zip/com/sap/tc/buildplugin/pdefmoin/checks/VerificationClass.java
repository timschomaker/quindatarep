package com.sap.tc.buildplugin.pdefmoin.checks;

import com.sap.tc.buildplugin.util.BuildPluginException;

/**
 * Interface for verification classes. A verification class runs a specific
 * check and returns true or false for the result of this check.
 */
public interface VerificationClass
{
	/**
	 * Run the verification. Returns true, if the test was successful, otherwise returns false.
	 *
	 * @return - true, if the test was successful, otherwise returns false
	 * @throws BuildPluginException
	 *             - thrown if the test fails unexpected
	 */
	public boolean verify() throws BuildPluginException;

	/**
	 * @return the description of the verification. Used for log messages
	 */
	public String getDescription();

	/**
	 * @return true, if the complete build should be aborted if this verification fails
	 */
	public boolean abortBuild();

	/**
	 * @return returns true, if no other verifications can run after this one, if this one fails
	 * some checks can failed and this means that some following
	 * checks will failed too. In such situation all following checks have not to be executed.
	 */
	public boolean stopOtherVerifications();
}
