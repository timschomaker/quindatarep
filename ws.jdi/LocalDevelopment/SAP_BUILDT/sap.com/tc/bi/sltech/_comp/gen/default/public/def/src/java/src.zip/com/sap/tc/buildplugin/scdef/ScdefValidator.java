package com.sap.tc.buildplugin.scdef;

import static com.sap.sld.api.wbem.sap.SLDElementNames.C_SAP_SoftwareComponent;
import static com.sap.sld.api.wbem.sap.SLDElementNames.P_ElementTypeID;
import static com.sap.sld.api.wbem.sap.SLDElementNames.P_GUID;
import static com.sap.sld.api.wbem.sap.SLDElementNames.P_Name;
import static com.sap.sld.api.wbem.sap.SLDElementNames.P_Vendor;
import static com.sap.sld.api.wbem.sap.SLDElementNames.P_Version;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

import org.apache.tools.ant.Task;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EcorePackage;

import com.sap.lm.slmodel.SlmodelPackage;
import com.sap.sld.api.util.MiscUtil;
import com.sap.sld.api.wbem.cim.CIMDeclaration;
import com.sap.sld.api.wbem.cim.CIMElement;
import com.sap.sld.api.wbem.cim.CIMInstance;
import com.sap.sld.api.wbem.cim.CIMObjectWithReference;
import com.sap.sld.api.wbem.cim.CIMProperty;
import com.sap.sld.api.wbem.cim.CIMReference;
import com.sap.sld.api.wbem.cim.CIMType;
import com.sap.sld.api.wbem.cim.CIMBaseProperty.Kind;
import com.sap.sld.api.wbem.cim.CIMDeclaration.CIMGroup;
import com.sap.sld.api.wbem.cim.CIMReference.CIMKey;
import com.sap.sld.api.wbem.exception.CIMException;
import com.sap.sld.api.wbem.sap.SLDElementNames;
import com.sap.sld.api.wbem.transform.CIMXmlParser;
import com.sap.sld.api.wbem.transform.CIMXmlWriter;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.util.BuildPluginException;

public class ScdefValidator extends EdenBuildPlugin
{

	protected static final String	DESCRIPTION_INPUT_FILENAME			= ".description";
	protected static final String	CONTENTZIP_INPUT_FILENAME			= "content.zip";
	protected final static String	MODEL_INPUT_FILENAME				= "cimmodel.dat";

	protected final static String	LD_CONTENT_OUTPUT_FILENAME			= "ld-content.zip";
	protected final static String	CR_CONTENT_OUTPUT_FILENAME			= "cr-content.zip";
	protected final static String	CIM_MODEL_OUTPUT_FILENAME			= "cimmodel.zip";

	protected final static String	SDA_DD_XML							= "sda-dd.xml";
	protected final static String	SDA_DD_XML_VELOCITY_VARIABLE		= "sda_dd_xml";

	protected final static String	DATA_DIR_PATH						= "data";
	protected final static String	MODEL_DATA_PATH						= DATA_DIR_PATH + "/" + MODEL_INPUT_FILENAME;

	protected static final byte[]	NEWLINE_BYTES						= MiscUtil.toUTF8(MiscUtil.NEWLINE);

	protected final static String	LOGFILE_NAME						= "sl_log.txt";

	protected final static String	MAP_KEY_NAME						= "Name";
	protected final static String	MAP_KEY_VERSION						= "Version";
	protected final static String	MAP_KEY_VENDOR						= "Vendor";
	protected final static String	MAP_KEY_ELEMENT_TYPE_ID				= "ElementTypeID";
	protected final static String	MAP_KEY_GUID						= "GUID";
	protected final static String	MAP_KEY_PRODUCT_IDENTIFYING_NUMBER	= "ProductIdentifyingNumber";
	protected final static String	MAP_KEY_PRODUCTLINE_PPMS_NUMBER		= "ProductLinePPMSNumber";

	protected final static String	SLD_CONTENT_DIR_01					= "sldpack_01";
	protected final static String	SLD_TEMP_DIR_01						= "sldtemp_01";

	protected final static String	ZIP_ENTRY_NAME						= "export01.xml";

	protected static final String	POSTFIX_XML							= ".xml";

	protected final List<String>	messages							= new ArrayList<String>();

	/**
	 * Starting point for execution of the build plugin functionality
	 * 
	 * @throws BuildPluginException
	 *             If execution fails.
	 */
	@Override
	public void execute(Task emfTask, List<File> sourceDirList, List<File> compilePPDirList, File packDir, File tempdir) throws BuildPluginException
	{
		EPackage.Registry.INSTANCE.put(EcorePackage.eNS_URI, EcorePackage.eINSTANCE);
		EPackage.Registry.INSTANCE.put(SlmodelPackage.eNS_URI, SlmodelPackage.eINSTANCE);
		
		try
		{
			final String methodName = "execute (on " + new Date() + ")";
			loggMethodStart(methodName);

			emfTask.log("Executing inside of " + getClass().getName() + "...");
			emfTask.log("packDir: " + packDir);
			emfTask.log("tempDir: " + tempdir);

			// Log message for start of execution
			loggMessage(this.getClass().getName() + ": Execution starts on " + new Date() + "\n");
			loggEmptyLine();

			if (!sourceDirList.isEmpty())
			{
				int i = 1;
				for (File sourceDir : sourceDirList)
				{
					loggFilePath("sourceDir" + i, sourceDir);
					i++;
				}
			}
			else
			{
				loggMessage("sourceDirList is empty.");
			}

			if (!compilePPDirList.isEmpty())
			{
				int i = 1;
				for (File compilePPDir : compilePPDirList)
				{
					loggFilePath("compilePPDir" + i, compilePPDir);
					i++;
				}
			}
			else
			{
				loggMessage("compilePPDirList is empty.");
			}

			// Pin down files relevant for later generation step in HashMap
			final List<String> inputFilenameList = getInputFilenameList();
			HashMap<String, File> inputFileMap = getInputFileMap(sourceDirList, inputFilenameList);
			if (inputFileMap.isEmpty())
			{
				throw new BuildPluginException("No input files found");
			}

			// Perform generation of output archive content
			generate(inputFileMap, packDir, tempdir, sourceDirList, compilePPDirList);
		}
		catch (CIMException e)
		{
			throw new BuildPluginException(e.getMessage(), e);
		}
		catch (IOException e)
		{
			throw new BuildPluginException(e.getMessage(), e);
		}
		finally
		{
			// Flush logging output
			loggMessage(this.getClass().getName() + ": Execution ends on " + new Date());
			try
			{
				loggFlush(packDir, LOGFILE_NAME);
				loggFlush(null, LOGFILE_NAME);
			}
			catch (BuildPluginException w)
			{
				// $JL-EXC$
			}
		}
	}

	/**
	 * @return List of names of input files that may be relevant for the generation process.
	 */
	protected List<String> getInputFilenameList()
	{
		return getScdefInputFilenameList();
	}

	/**
	 * @return List of names of input files that may be relevant for the generation process.
	 */
	protected List<String> getScdefInputFilenameList()
	{
		final List<String> fileNameList = new ArrayList<String>();
		fileNameList.add(CONTENTZIP_INPUT_FILENAME);
		fileNameList.add(DESCRIPTION_INPUT_FILENAME);
		return fileNameList;
	}

	/**
	 * Start the deploy archive and deployment descriptor generation
	 * 
	 * @param inputFileMap
	 *            Input files to be used (filename -> absolute path), not empty.
	 * @param gendir
	 *            Packing directory
	 * @param tempdir
	 *            Temporary directory for files necessary to create which should not be packed.
	 * @throws BuildPluginException
	 *             On failure
	 * @throws CIMException
	 *             On failure
	 * @throws IOException
	 *             On failure
	 */
	protected void generate(HashMap<String, File> inputFileMap, File gendir, File tempdir, List<File> sourceDirList, List<File> compilePPDirList)
			throws BuildPluginException, CIMException, IOException
	{
		final String methodName = "generate";
		loggMethodStart(methodName);
		HashMap<String, String> scValuesMap = getSoftcompValueMap(inputFileMap);
		generateSoftwareComponent(scValuesMap, gendir);
		generateDeploymentDescriptor(tempdir);
		loggMethodEnd(methodName);
	}

	/**
	 * Generate the deploy archive deployment descriptor. Put absolute path into Velocity
	 * environment.
	 * 
	 * @param tempdir
	 *            Temporary directory for assemblage of deployment descriptor file
	 * @throws IOException
	 */
	protected StringBuffer getDeploymentDescriptorContent() throws IOException
	{
		StringBuffer buffer = new StringBuffer(200);
		buffer.append("<SDA>\n");
		buffer.append("  <SoftwareType>CONTENT</SoftwareType>\n");
		buffer.append("  <sl-sda-deployment-descriptor>\n");
		buffer.append("    <sl-sda-logical-type>LD-SDA</sl-sda-logical-type>\n");
		buffer.append("      <ld-files>\n");
		buffer.append("        <ld-file>" + LD_CONTENT_OUTPUT_FILENAME + "</ld-file>\n");
		buffer.append("      </ld-files>\n");
		buffer.append("  </sl-sda-deployment-descriptor>\n");
		buffer.append("</SDA>\n");
		return buffer;
	}

	/**
	 * Write deployment descriptor to filesystem. Later to be picked up by velocity.
	 * 
	 * @param tempdir
	 *            Directory where to write to
	 * @param buffer
	 *            Content to write
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	final protected void generateDeploymentDescriptor(File tempdir) throws FileNotFoundException, IOException
	{
		StringBuffer buffer = getDeploymentDescriptorContent();
		File sdadd = new File(tempdir, SDA_DD_XML);
		BufferedOutputStream bout = new BufferedOutputStream(new FileOutputStream(sdadd));
		bout.write(MiscUtil.toUTF8(buffer.toString()));
		bout.close();
	}

	/**
	 * Generate the LD archive content.
	 * 
	 * @param scValueMap
	 *            Map containing the values to generate from
	 * @param gendir
	 *            Generation directory where later on Velocity packing will tale place.
	 */
	final protected void generateSoftwareComponent(HashMap<String, String> scValueMap, File gendir) throws BuildPluginException, CIMException, IOException
	{
		final String methodName = "generateSoftwareComponent";
		loggMethodStart(methodName);

		ZipOutputStream ostream = null;
		try
		{
			// Create basic CIMInstance for current SoftwareComponent
			CIMInstance cimInst = new CIMInstance(SLDElementNames.C_SAP_SoftwareComponent);
			CIMProperty cimPropName = new CIMProperty(SLDElementNames.P_Name, CIMType.STRING, scValueMap.get(MAP_KEY_NAME));
			CIMProperty cimPropVend = new CIMProperty(SLDElementNames.P_Vendor, CIMType.STRING, scValueMap.get(MAP_KEY_VENDOR));
			CIMProperty cimPropVers = new CIMProperty(SLDElementNames.P_Version, CIMType.STRING, scValueMap.get(MAP_KEY_VERSION));
			cimInst.setBaseProperty(cimPropName);
			cimInst.setBaseProperty(cimPropVend);
			cimInst.setBaseProperty(cimPropVers);

			// Special elementTypeID handling, use zero if undefined
			String elementTypeID = scValueMap.get(MAP_KEY_ELEMENT_TYPE_ID);
			if (elementTypeID == null)
			{
				// No PPMS numbers available, use "0" for ElementTypeID
				elementTypeID = "0";
			}
			CIMProperty cimPropEtId = new CIMProperty(SLDElementNames.P_ElementTypeID, CIMType.STRING, elementTypeID);
			cimInst.setBaseProperty(cimPropEtId);

			// Create reference from CIMInstance
			CIMReference cimRef = new CIMReference(null, null, C_SAP_SoftwareComponent);
			for (Iterator<?> iter = cimInst.iterateProperties(Kind.PROPERTY); iter.hasNext();)
			{
				CIMProperty property = (CIMProperty) iter.next();
				cimRef.setKey(new CIMKey(property.getElementName(), property.getType(), property.getValue()));
			}

			// Special GUID handling, after creation of reference because it is not a key. Add GUID
			// only if defined in input files.
			String guid = scValueMap.get(MAP_KEY_GUID);
			if (guid != null)
			{
				// GUID available
				CIMProperty cimPropGuid = new CIMProperty(SLDElementNames.P_GUID, CIMType.STRING, guid);
				cimInst.setBaseProperty(cimPropGuid);
			}

			// Create object-with-reference compound, group and declaration, then assemble
			CIMObjectWithReference cimObjWRef = new CIMObjectWithReference(cimRef, cimInst);
			CIMGroup cimGroup = new CIMGroup();
			cimGroup.add(cimObjWRef);
			CIMDeclaration cimDecl = new CIMDeclaration();
			cimDecl.add(cimGroup);

			// Create output file for generation content
			File ofile = new File(gendir, LD_CONTENT_OUTPUT_FILENAME);
			ostream = new ZipOutputStream(new FileOutputStream(ofile));
			ostream.putNextEntry(new ZipEntry(ZIP_ENTRY_NAME));

			// Write to build output file
			CIMXmlWriter xmlWriter = new CIMXmlWriter(true);
			xmlWriter.write(ostream, cimDecl);
		}
		catch (IOException e)
		{
			throw new BuildPluginException(e.getMessage(), e);
		}
		finally
		{
			if (ostream != null)
			{
				ostream.close();
			}
		}
		loggMethodEnd(methodName);
	}

	/**
	 * Compute HashMap object to be used for generation of output content, either from content.zip
	 * or .description file handed in (one of them must be defined) Contains the following keys
	 * PROP_NAME * mandatory * PROP_VERSION * mandatory * PROP_VENDOR * mandatory *
	 * PROP_ELEMENT_TYPE_ID * may be undefined * PROP_GUID * may be undefined *
	 * 
	 * @param fileMap
	 *            Map of files to process for filling the result.
	 * @return HashMap containing entries for name, version and vendor (mandatory), and maybe also
	 *         for elementTypeID and guid
	 * @throws IOException
	 * @throws BuildPluginException
	 * @throws FileNotFoundException
	 */
	protected HashMap<String, String> getSoftcompValueMap(HashMap<String, File> fileMap) throws IOException, BuildPluginException, FileNotFoundException
	{
		final String methodName = "getSoftcompValueMap";
		loggMethodStart(methodName);
		loggHashMap("InputFileMap", fileMap);

		final HashMap<String, String> result = new HashMap<String, String>();
		final File contentzipFile = fileMap.get(CONTENTZIP_INPUT_FILENAME);
		final File descriptionFile = fileMap.get(DESCRIPTION_INPUT_FILENAME);

		// if (descriptionFile == null && contentzipFile == null) {
		// throw new BuildPluginException("Missing data files for software component values");
		// }

		// Choose which files to read
		if (contentzipFile != null)
		{
			messages.add("Reading softcomp info from: " + contentzipFile.getAbsolutePath());
			// Content file is present, exported by IDE from connected SLD
			CIMDeclaration parseResult = null;
			try
			{
				ZipFile zippy = new ZipFile(contentzipFile.getAbsolutePath());

				zip_entry_loop: for (Enumeration<? extends ZipEntry> entries = zippy.entries(); entries.hasMoreElements();)
				{
					ZipEntry entry = entries.nextElement();
					if (entry.getName().endsWith(POSTFIX_XML))
					{
						CIMXmlParser cimParser = new CIMXmlParser();
						parseResult = (CIMDeclaration) cimParser.parse(zippy.getInputStream(entry));
						loggMessage(parseResult.toString());
						for (Iterator<CIMGroup> cimGroupIter = parseResult.iterateGroups(); cimGroupIter.hasNext();)
						{
							CIMGroup group = cimGroupIter.next();
							loggMessage(group.toString());
							for (Iterator<CIMElement> groupIter = group.iterateObjects(); groupIter.hasNext();)
							{
								CIMElement element = groupIter.next();
								if (element instanceof CIMObjectWithReference)
								{
									CIMObjectWithReference ref = (CIMObjectWithReference) element;
									CIMInstance inst = ref.getInstance();
									if (inst != null && inst.getElementName().compareTo(C_SAP_SoftwareComponent) == 0)
									{
										createEntryInValueMap(result, MAP_KEY_NAME, inst.getValue(P_Name), true);
										createEntryInValueMap(result, MAP_KEY_VERSION, inst.getValue(P_Version), true);
										createEntryInValueMap(result, MAP_KEY_VENDOR, inst.getValue(P_Vendor), true);
										createEntryInValueMap(result, MAP_KEY_ELEMENT_TYPE_ID, inst.getValue(P_ElementTypeID), false);
										createEntryInValueMap(result, MAP_KEY_GUID, inst.getValue(P_GUID), false);
										loggMessage("Extracting: " + element.getClass() + " : " + element.toString());
										break zip_entry_loop;
									}
								}
							}
						}
					}
				}
			}
			catch (CIMException e)
			{
				throw new BuildPluginException("CIMXmlParsing failed", e);
			}
		}
		else
		{
			// messages.add("Reading softcomp info from: " + descriptionFile.getAbsolutePath());
			readNameVersionVendorFromDescription(result, descriptionFile);
		}
		loggHashMap("SoftcompValueMap", result);
		loggMethodEnd(methodName);
		return result;
	}

	/**
	 * Look up files relevant in generation.
	 * 
	 * @param dirList
	 *            Directories to search
	 * @param filenameList
	 *            Filenames to search
	 * @return HashMap containing filenames as key and found File object as value. May be empty if
	 *         no file was found.
	 */
	protected HashMap<String, File> getInputFileMap(List<File> dirList, List<String> filenameList)
	{
		// Result map
		HashMap<String, File> resultMap = new HashMap<String, File>();

		for (Iterator<File> fileIter = dirList.iterator(); fileIter.hasNext();)
		{
			// Loop over directories
			File nextDir = fileIter.next();

			for (Iterator<String> filenameIter = filenameList.iterator(); filenameIter.hasNext();)
			{
				// Loop over filenames
				String nextFilename = filenameIter.next();
				if (resultMap.containsKey(nextFilename))
				{
					// Already found, skip
					continue;
				}
				File nextCandidate = new File(nextDir, nextFilename);
				if (nextCandidate.exists())
				{
					resultMap.put(nextFilename, nextCandidate);
				}
			}
		}
		return resultMap;
	}

	protected void loggMessage(String msg)
	{
		messages.add(msg);
	}

	protected void loggFilePath(String filename, File file)
	{
		String path = (file == null) ? "<null>" : file.getAbsolutePath();
		loggMessage("File: " + filename + ": " + path);
	}

	protected <K, V> HashMap<K, V> loggHashMap(String name, HashMap<K, V> map)
	{
		String desc = (map == null) ? "<null>" : map.toString();
		loggMessage(name + ": " + desc);
		return map;
	}

	protected void loggList(String name, List<String> list)
	{
		StringBuffer buf = new StringBuffer();
		boolean oneWritten = false;
		buf.append(name).append(": ");
		for (Iterator<String> iter = list.iterator(); iter.hasNext();)
		{
			String next = iter.next();
			if (oneWritten)
			{
				buf.append(", ");
			}
			else
			{
				oneWritten = true;
			}
			buf.append(next);
		}
		loggMessage(buf.toString());
	}

	protected void loggEmptyLine()
	{
		loggMessage("\n");
	}

	protected void loggFileCopy(String outputFileName, File inputFile, File outputFile)
	{
		loggMessage("Creating " + outputFileName + ": copied " + inputFile.getAbsolutePath() + " to " + outputFile.getAbsolutePath());
	}

	protected void loggResourceCopy(String outputFileName, String resourceName, File outputFile)
	{
		loggMessage("Creating " + outputFileName + ": copied resource " + resourceName + " to " + outputFile.getAbsolutePath());
	}

	protected void loggMethodStart(String name)
	{
		loggMessage(">>> === " + name + "===");
	}

	protected void loggMethodEnd(String name)
	{
		loggMessage("<<< === " + name + "===");
	}

	/**
	 * Flush log to directory handed in, with name also handed in. In case logdir is
	 * <code>null</code>, the file will be written to the BuildSession logdir.
	 * 
	 * @param logdir
	 *            The directory to write to, maybe <code>null</code>
	 * @param logfileName
	 *            The wname of the logfile to write
	 * @throws BuildPluginException
	 */
	private void loggFlush(File logdir, String logfileName) throws BuildPluginException
	{
		if (logdir == null)
		{
			// If logdir is undefined for any reason, write log into build logging directory
			// Normally, the directory handed in will be the packing directory, so the log gets
			// packed with the other results
			IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.SESSION_KEY);
			logdir = pbi.getLogDir();
		}
		try
		{
			File ofile = new File(logdir, logfileName);
			OutputStream ostream = new BufferedOutputStream(new FileOutputStream(ofile));

			Iterator<String> messageIter = messages.iterator();
			while (messageIter.hasNext())
			{
				String msg = messageIter.next();
				ostream.write(MiscUtil.toUTF8(msg));
				ostream.write(NEWLINE_BYTES);
			}
			ostream.close();
		}
		catch (IOException e)
		{
			throw new BuildPluginException(e.getMessage(), e);
		}
	}

	/**
	 * Create an entry in the value map
	 * 
	 * @param valueMap
	 *            Map to create entry in
	 * @param key
	 *            Key to be set
	 * @param value
	 *            Value to be set
	 * @param requireValueNotNull
	 *            true if value must not be null
	 * @throws BuildPluginException
	 *             If value is null although it should not be
	 */
	protected void createEntryInValueMap(HashMap<String, String> valueMap, String key, String value, boolean requireValueNotNull) throws BuildPluginException
	{
		if (requireValueNotNull && value == null)
		{
			throw new BuildPluginException("Trying to add required value as <null> to value map");
		}
		valueMap.put(key, value);
	}

	/**
	 * Read name, version and vendor from the .description file. All three keys must be there, else
	 * an Exception occurs
	 * 
	 * @param result
	 *            The map to be filled
	 * @param descriptionFile
	 *            Description file to be read
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @throws BuildPluginException
	 */
	protected void readNameVersionVendorFromDescription(final HashMap<String, String> result, final File descriptionFile) throws IOException,
			FileNotFoundException, BuildPluginException
	{
		boolean containsName = false;
		boolean containsVersion = false;
		boolean containsVendor = false;

		if (descriptionFile != null)
		{
			Properties tmpProps = new Properties();
			tmpProps.load(new BufferedInputStream(new FileInputStream(descriptionFile)));
			for (Enumeration<?> propsEnum = tmpProps.keys(); propsEnum.hasMoreElements();)
			{
				String key = (String) propsEnum.nextElement();
				if (key.equalsIgnoreCase(MAP_KEY_NAME))
				{
					createEntryInValueMap(result, MAP_KEY_NAME, (String) tmpProps.get(key), true);
					containsName = true;
					continue;
				}
				if (key.equalsIgnoreCase(MAP_KEY_VERSION))
				{
					createEntryInValueMap(result, MAP_KEY_VERSION, (String) tmpProps.get(key), true);
					containsVersion = true;
					continue;
				}
				if (key.equalsIgnoreCase(MAP_KEY_VENDOR))
				{
					createEntryInValueMap(result, MAP_KEY_VENDOR, (String) tmpProps.get(key), true);
					containsVendor = true;
					continue;
				}
				if (key.equalsIgnoreCase(MAP_KEY_ELEMENT_TYPE_ID))
				{
					createEntryInValueMap(result, MAP_KEY_ELEMENT_TYPE_ID, (String) tmpProps.get(key), true);
					continue;
				}
				if (key.equalsIgnoreCase(MAP_KEY_GUID))
				{
					createEntryInValueMap(result, MAP_KEY_GUID, (String) tmpProps.get(key), true);
					continue;
				}
			}
		}
		else
		{
			createEntryInValueMap(result, MAP_KEY_NAME, "MyName", true);
			containsName = true;

			createEntryInValueMap(result, MAP_KEY_VERSION, "1.0", true);
			containsVersion = true;

			createEntryInValueMap(result, MAP_KEY_VENDOR, "sap.com", true);
			containsVendor = true;

			createEntryInValueMap(result, MAP_KEY_ELEMENT_TYPE_ID, "0", true);
			createEntryInValueMap(result, MAP_KEY_GUID, "0", true);
		}

		// Check map for minimal completeness: MAP_KEY_NAME, MAP_KEY_VERSION, MAP_KEY_VENDOR
		if (!(containsName && containsVendor && containsVersion))
		{
			String path = descriptionFile == null ? "not available" : descriptionFile.getAbsolutePath();
			throw new BuildPluginException("Incomplete .description file: " + path);
		}
	}

	/**
	 * @return The list of strings describing the relative pathes of FunDCMapping files copied to
	 *         the SDA during build of the DC. May be empty.
	 */
	protected ArrayList<String> getFunDcMapPathes()
	{
		return new ArrayList<String>();
	}
}
